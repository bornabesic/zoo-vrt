
INSERT INTO `classes` (`class_id`, `name`) VALUES ('1', 'Aves');
INSERT INTO `classes` (`class_id`, `name`) VALUES ('2', 'Reptilia');
INSERT INTO `classes` (`class_id`, `name`) VALUES ('3', 'Amphibia');
INSERT INTO `classes` (`class_id`, `name`) VALUES ('4', 'Actinopterygii');
INSERT INTO `classes` (`class_id`, `name`) VALUES ('5', 'Mammalia');

INSERT INTO `orders` (`order_id`, `name`, `parent_class_id`) VALUES ('1', 'Rodentia', '5');
INSERT INTO `orders` (`order_id`, `name`, `parent_class_id`) VALUES ('2', 'Macroscelidea', '5');
INSERT INTO `orders` (`order_id`, `name`, `parent_class_id`) VALUES ('3', 'Hyracoidea', '5');
INSERT INTO `orders` (`order_id`, `name`, `parent_class_id`) VALUES ('4', 'Dasyuromorphia', '5');
INSERT INTO `orders` (`order_id`, `name`, `parent_class_id`) VALUES ('5', 'Artiodactyla', '5');
INSERT INTO `orders` (`order_id`, `name`, `parent_class_id`) VALUES ('6', 'Primates', '5');
INSERT INTO `orders` (`order_id`, `name`, `parent_class_id`) VALUES ('7', 'Psittaciformes', '1');
INSERT INTO `orders` (`order_id`, `name`, `parent_class_id`) VALUES ('8', 'Piciformes', '1');
INSERT INTO `orders` (`order_id`, `name`, `parent_class_id`) VALUES ('9', 'Passeriformes', '1');
INSERT INTO `orders` (`order_id`, `name`, `parent_class_id`) VALUES ('10', 'Squamata', '2');
INSERT INTO `orders` (`order_id`, `name`, `parent_class_id`) VALUES ('11', 'Testudines', '2');
INSERT INTO `orders` (`order_id`, `name`, `parent_class_id`) VALUES ('12', 'Anura', '3');
INSERT INTO `orders` (`order_id`, `name`, `parent_class_id`) VALUES ('13', 'Caudata', '3');
INSERT INTO `orders` (`order_id`, `name`, `parent_class_id`) VALUES ('14', 'Siluriformes', '4');


INSERT INTO `families` (`family_id`, `name`, `parent_order_id`) VALUES ('1', 'Dasyproctidae', '1');
INSERT INTO `families` (`family_id`, `name`, `parent_order_id`) VALUES ('2', 'Muridae', '1');
INSERT INTO `families` (`family_id`, `name`, `parent_order_id`) VALUES ('3', 'Leporidae', '1');
INSERT INTO `families` (`family_id`, `name`, `parent_order_id`) VALUES ('4', 'Sciuridae', '1');
INSERT INTO `families` (`family_id`, `name`, `parent_order_id`) VALUES ('5', 'Macroscelididae', '2');
INSERT INTO `families` (`family_id`, `name`, `parent_order_id`) VALUES ('6', 'Procaviidae', '3');
INSERT INTO `families` (`family_id`, `name`, `parent_order_id`) VALUES ('7', 'Dasyuridae', '4');
INSERT INTO `families` (`family_id`, `name`, `parent_order_id`) VALUES ('8', 'Bovidae', '5');
INSERT INTO `families` (`family_id`, `name`, `parent_order_id`) VALUES ('9', 'Atelidae', '6');
INSERT INTO `families` (`family_id`, `name`, `parent_order_id`) VALUES ('10', 'Psittacidae', '7');
INSERT INTO `families` (`family_id`, `name`, `parent_order_id`) VALUES ('11', 'Capitonidae', '8');
INSERT INTO `families` (`family_id`, `name`, `parent_order_id`) VALUES ('12', 'Fringillidae', '9');
INSERT INTO `families` (`family_id`, `name`, `parent_order_id`) VALUES ('13', 'Viperidae', '10');
INSERT INTO `families` (`family_id`, `name`, `parent_order_id`) VALUES ('14', 'Testudinidae', '11');
INSERT INTO `families` (`family_id`, `name`, `parent_order_id`) VALUES ('15', 'Dendrobatidae', '12');
INSERT INTO `families` (`family_id`, `name`, `parent_order_id`) VALUES ('16', 'Salamandridae', '12');
INSERT INTO `families` (`family_id`, `name`, `parent_order_id`) VALUES ('17', 'Loricariidae', '14');
INSERT INTO `families` (`family_id`, `name`, `parent_order_id`) VALUES ('18', 'Mochokidae', '14');


INSERT INTO `species` (`species_id`, `name`, `family_id`, `size`, `nutrition`, `predators`, `lifetime`, `habitat`, 

`lifestyle`, `reproduction`, `distribution`, `location_x`, `location_y`, `photo_path`) VALUES ('1', 'ZLATNI AGUTI 

(Dasyprocta leporina)', '1', 'Veličina tijela: od 48 do 64 cm, rep do 6 cm
Težina tijela: od 3 do 6 kg', 'U prirodi: sjemenke, plodovi, lišće i korijenje, rijetko ličinke kukaca.
U zoo vrtu: voće, povrće, orašasti plodovi, žitarice, suncokretove sjemenke, peletirana hrana za svejede, livadno 

sijeno, svježa trava, brst (svježe grane graba, jasena, javora, vrbe, lijeske, itd.)', 'Nema dostupnih podataka', 'U 

prirodi: nema dostupnih podataka
U zoo vrtu: 15 do 20 godina', 'Tropske šume u blizini vode', 'Aktivne su danju, osim kod prisutnosti predatora, kada 

mogu biti aktivne noću. Samotnjačke su životinje, osim za perioda razmnožavanja, kada ženke tjeraju druge ženke, a 

mužjaci se bore s drugim mužjacima. Sakrivaju se u grmlju, ispod kamenja ili u rupama koje su iskopale druge male 

životinje. ', 'Monogame su vrste, što znači da imaju samo jednog partnera. Nemaju određenu sezonu razmnožavanja. Nakon 

gestacije od 104 do 120 dana, ženke imaju jedno do četiri mladunaca. Mladunci vrlo brzo mogu skakati i trčati. ', 'Jug 

Afrike', '308', '132', '/media/ZLATNI_AGUTI.jpg');

INSERT INTO `species` (`species_id`, `name`, `family_id`, `size`, `nutrition`, `predators`, `lifetime`, `habitat`, 

`lifestyle`, `reproduction`, `distribution`, `location_x`, `location_y`, `photo_path`) VALUES ('2', 'SLONOVSKA ROVČICA 

(Macroscelides proboscideus)', '5', 'Veličina tijela: 10 do 11 cm, rep 10 do 13 cm
Težina tijela: 40 do 50 g', 'U prirodi: kukci, posebno termiti i mravi te ostali mali beskralježnjaci, korijenje i 

plodovi biljaka.
U zoo vrtu: voće, povrće, meka hrana za kukcojedne ptice, cvrčci, skakavci, klice', 'Jastrebovi', 'U prirodi: 1 do 2 

godine
U zoo vrtu: 3 do 4 godine', 'Pustinje i polupustinje', 'Aktivne su danju, osim kod prisutnosti predatora, kada mogu 

biti aktivne noću. Samotnjačke su životinje, osim za perioda razmnožavanja, kada ženke tjeraju druge ženke, a mužjaci 

se bore s drugim mužjacima. Sakrivaju se u grmlju, ispod kamenja ili u rupama koje su iskopale druge male životinje.', 

'Period razmnožavanja je u toplim i vlažnim mjesecima, kolovozu i rujnu, a tijekom tog perioda ženka može imati 

nekoliko trudnoća. Period gestacije traje 56 dana, a mladunci se rađaju s krznom i otvorenim očima, a već za nekoliko 

sati mogu trčati i skakati. Ženka obično ima dva, rjeđe jednog mladunca. Ženka ne čuva mlade te većinu dana nije 

prisutna. Dolazi samo jednom dnevno da ih nahrani.', 'Jug Afrike', '308', '132', '/media/SLONOVSKA_ROVČICA.jpg');

INSERT INTO `species` (`species_id`, `name`, `family_id`, `size`, `nutrition`, `predators`, `lifetime`, `habitat`, 

`lifestyle`, `reproduction`, `distribution`, `location_x`, `location_y`, `photo_path`) VALUES ('3', 'PLANINSKI PEĆINAR 

(Procavia capensis)', '6', 'Veličina tijela: 30,5 do 55 cm
Težina tijela: 3,8 do 4,3 kg, mužjaci teži od ženki', 'U prirodi: trava, lišće, plodovi, kora, lišajevi.
U zoo vrtu: lišće, sjeno, briketi, razne biljke', 'Zmije, ptice grabljivice, divlji psi, serval, lav, mungos', 'U 

prirodi: 12 godina
U zoo vrtu: 11 godina', 'Pustinje, savane i šikare', 'Žive u kolonijama koje, kada je dovoljno mjesta i hrane, mogu 

brojati 80 jedinki. Kolonije čine mužjak s nekoliko svojih ženki i svim potomstvom ili nekoliko obitelji tj. harema, 

svaki s glavnim mužjakom. Među ženkama nije zabilježena hijerarhija, iako su starije ženke često dominantnije. Mladi 

mužjaci prisiljeni su na odlazak iz kolonije, ali često se zadržavaju u bližim jazbinama unutar teritorija. Kada 

dominantan mužjak ugine zamijenit će ga najjači mužjak. Vrlo dobro podnose fluktuacije temperature, ali ovise o 

zaklonima kako bi se sakrili od ekstremnih uvjeta. Većinu vremena provode mirujući ili drijemajući u jazbinama ili 

hladu.', 'Mužjaci imaju harem od 3 do 7 ženki, a parenje je sezonsko, kako bi se mladunci okotili za kišne sezone. 

Mužjaci se glasaju i približavaju ženkama, pri čemu ih one mogu napasti ukoliko se ne žele pariti. Tijekom sezone 

parenja testisi mužjaka mogu narasti i do 20 puta, što dovodi do čestog glasanja i agresivnosti. Gestacija traje 6 do 

8 mjeseci. Tijekom gestacije ženke su vrlo agresivne. ', 'Afrika i Arapski poluotok', '308', '132', 

'/media/PLANINSKI_PEĆINAR.jpg');

INSERT INTO `species` (`species_id`, `name`, `family_id`, `size`, `nutrition`, `predators`, `lifetime`, `habitat`, 

`lifestyle`, `reproduction`, `distribution`, `location_x`, `location_y`, `photo_path`) VALUES ('4', 'OBLAČASTI ŠTAKOR 

(Phloeomys pallidus)', '2', 'Veličina tijela: 69 do 75 cm, rep 30 do 32 cm
Težina tijela: 2,6 kg', 'U prirodi: mladi listovi, voće, cvijeće, sjemenke i usjevi.
U zoo vrtu: povrće, peletirana hrana za biljojede, livadno sijeno, sijeno lucerne, svježa trava, brst (svježe grane 

graba, jasena, javora, vrbe, lijeske, itd.) ', 'Osim za čovjeka, nema dostupnih podataka. ', 'U prirodi: nema 

dostupnih podataka
U zoo vrtu: 13 godina', 'Tropske šume i plantaže', 'Noćne su životinje i većinu vremena provode u krošnjama.', 

'Istraživanje razmnožavanja vršeno je samo u zatočeništvu. Ženke su imale mlade u svim mjesecima osim siječnja, ožujka 

i svibnja. Ženke jednom godišnje imaju samo jedno mlado koje nose čvrsto priljubljeno uz bradavicu.', 'Filipini', 

'308', '132', '/media/OBLAČASTI_ŠTAKOR.jpg');

INSERT INTO `species` (`species_id`, `name`, `family_id`, `size`, `nutrition`, `predators`, `lifetime`, `habitat`, 

`lifestyle`, `reproduction`, `distribution`, `location_x`, `location_y`, `photo_path`) VALUES ('5', 'ŠUMSKI MIŠ 

(Apodemus sylvaticus)', '2', 'Dužina tijela: 60 - 150 mm
Težina tijela:  23,4 g
Dužina repa: 70 - 145 mm', 'U prirodi:  korijenje, žitarice, sjemenke, bobice, orasi, trava, žitarice, voće i insekti
U zoo vrtu: voće, povrće, mješavina sjemenki za zamorce, cvrčci, klice', 'Sove, zmije, lisice', 'U prirodi:  1 godina
U zatočeništvu: 4 godina', 'Travnate i kultivirane površine, šume i šumska područja', 'Jako su dobri penjači, skakači 

i plivači. Noćne su ili sumračne životinje. Mužjaci žive na području promjera 109 m, a ženke 64 m. Kada ne žive blizu 

ljudi kopaju jazbine i tunele ispod površine tla. Sastoje se od kružih tunela oko korijenja stabala koji vode do 

drugog tunela ispod stabla do komore za gniježđenje, dok ostali tuneli služe kao prolazi do ulaza koja su obično dva.
', 'Nema dostupnih podataka', 'Europa, osim Skandinavije i Finske, jugozapadna Azija, Himalaja, sjeverozapadna Afrika, 

Velika Britanija', '308', '132', '/media/ŠUMSKI_MIŠ.jpg');

INSERT INTO `species` (`species_id`, `name`, `family_id`, `size`, `nutrition`, `predators`, `lifetime`, `habitat`, 

`lifestyle`, `reproduction`, `distribution`, `location_x`, `location_y`, `photo_path`) VALUES ('6', 'ISTOČNA 

TOBOLČARSKA MAČKA (Dasyurus viverrinus)', '7', 'Veličina tijela: od 35 do 45 cm, rep od 21 do 30 cm
Težina tijela: ženke od 600 do 1030 g, mužjaci od 850 do 1550 g', 'U prirodi: kukci, mali kralježnjaci, rijetko 

strvine i voće
U zoo vrtu: štakori, pilići', 'Psi', 'U prirodi: 5 godina
U zoo vrtu: 6,8 godina', 'Kišne šume i šume', 'Samotnjačke su i noćne životinje. Noć provode loveći plijen. Iako se 

mogu penjati na stabla, većinom se zadržavaju na tlu. U velikoj su kompeticiji s autohtonim i unesenim vrstama 

predatora.', 'Period parenja je od kasne jeseni do rane zime (južna polutka). Ženka može okotiti do 30 mladunaca iako 

ima samo 3 do 4 pari mammae (bradavica) i može othraniti samo toliko embrija u tobolcu. Mladi u tobolcu ostaju do 8 

tjedana. ', 'Tasmanija', '308', '132', '/media/ISTOČNA_TOBOLČARSKA_MAČKA.jpg');

INSERT INTO `species` (`species_id`, `name`, `family_id`, `size`, `nutrition`, `predators`, `lifetime`, `habitat`, 

`lifestyle`, `reproduction`, `distribution`, `location_x`, `location_y`, `photo_path`) VALUES ('7', 'KUNIĆ 

(Oryctolagus cuniculus)', '3', 'Veličina tijela: 38 cm do 50 cm
Težina tijela: 1,5 do 2,5 kg', 'U prirodi: Trave, lišće, korijenje, kora stabala
U zoo vrtu: Sijeno, peleti, lišće ', 'Većina grabežljivaca - psi, mačke, ptice grabljivice, vidre', 'U prirodi: 1 

godina
U zoo vrtu: 9 godina', 'Travnjaci, šume – područja gdje meka zemlja omogućuje kopanje jazbina', 'Društvene su i 

teritorijalne životinje. Ukoliko je tlo povoljno za kopanje jazbina, skupina do 10 kunića će iskopati kompleksan 

sustav tunela. Hijerarhija u skupini najizraženija je među mužjacima. ', 'Kunići su poznati po svojoj reprodukciji. 

Mogu se razmnožavati cijelu godinu, međutim, pare se većinom u prvoj polovici godine. Nakon gestacije od 30 dana ženka 

rađa 5 do 6 mladunaca. Kod ženki su pobačaji ili apsorpcija fetusa uobičajeni, ali ženke unatoč tome godišnje imaju 

više legla. Slijepe i bespomoćne mladunce majka posjećuje tek nekoliko minuta dnevno. Mlijeko je vrlo bogato i 

hranjivo.', 'Globalna rasprostranjenost kunića, dok ih u divljini nalazimo na svim kontinentima osim Azije i 

Antartike', '308', '132', '/media/KUNIĆ.jpg');

INSERT INTO `species` (`species_id`, `name`, `family_id`, `size`, `nutrition`, `predators`, `lifetime`, `habitat`, 

`lifestyle`, `reproduction`, `distribution`, `location_x`, `location_y`, `photo_path`) VALUES ('8', 'PATULJASTA KOZA 

(Capra hircus)', '8', 'Veličina tijela: 26 cm do 107 cm
Težina tijela: 9 do 113 g', 'U prirodi: Trave i grmlja
U zoo vrtu: Trave i grmlja ', 'Kojoti, psi, planinski lavovi, lisice, orlovi i risovi.', 'U prirodi: nema podataka
U zoo vrtu: 15 do 22 godine', 'Travnjaci', 'Društvene su životinje i preferiraju prisutnost ostalih koza. Dnevne su 

životinje i većinu vremena provode pasući. Krda mogu sadržavati do 100 jedinki, a sačinjavati ih mogu samo mužjaci, 

samo ženke ili mogu biti miješana. U krdima postoji hijerarhija koja se održava povremenim borbama. ', 'Reprodukcija 

se najčešće odvija u kontroliranim uvjetima. Ukoliko se ne kontrolira, mužjaci će se međusobno natjecati za ženke. 

Onaj koji borbom pobjedi ostale mužjake moći će se pariti s više ženki. Razdoblja razmnožavanja ženki mogu se 

kontrolirati izlaganjem ženki dnevnom svjetlu, pa tako ženke u tropskim područjima mogu imati mlade tokom cijele 

godine, dok je sezona u ostatku svijeta od kasnog ljeta do rane zime. Mužjaci su spolno zreli s pet mjeseci, a ženke s 

jednom godinom. Nakon gestacije od oko 150 dana rađaju 1 do 3 mladunaca. ', 'Globalno rasprostranjene', '400', '141', 

'/media/PATULJASTA_KOZA.jpg');

INSERT INTO `species` (`species_id`, `name`, `family_id`, `size`, `nutrition`, `predators`, `lifetime`, `habitat`, 

`lifestyle`, `reproduction`, `distribution`, `location_x`, `location_y`, `photo_path`) VALUES ('9', 'CRVENA VJEVERICA 

(Sciurus vulgaris)', '4', 'Veličina tijela: 21 cm, rep preko 15 cm
Težina tijela: oko 350 g', 'U prirodi: plodovi i sjemenke različitih stabala poput bukve, žira, oraha i lješnjaka, ali 

i gljive, ptičja jaja, povrće i cvijeće.
U zoo vrtu:  ', 'Ptice grabljivice, kune, zmije penjašice', 'U prirodi: 4 do 6 godina
U zoo vrtu: 4 do 6 godina', 'Listopadne ili crnogorične šume', 'Većina aktivnosti crvenih vjeverica svodi se na 

pronalazak hrane, a najaktivnije su ujutro i kasno poslijepodne.  Tijekom proljeća i ljeta odmaraju se u gnijezdima i 

izbjegavaju najviše dnevne temperature. Iako većinu života provode na stablima, znaju i silaziti na tlo u potrazi za 

hranom ili kako bi zakopali hranu. Nisu teritorijalni i područje rasprostranjenosti često se isprepliće s drugima. 

Vrlo su spretne i agilne i konstantno na oprezu od predatora. ', 'Kada je ženka spremna za parenje mnogi mužjaci 

dolaze u njezino područje te dolazi do kompeticije za parenje. Nakon parenja svi mužjaci vraćaju se u svoje područje. 

Ženke godišnje obično imaju dva legla od po 5 do 7 mladunaca koji pri rođenju teže svega 8 do 12 g, nemaju krzna i 

slijepi su. Period gestacije traje 38 do 39 dana.', 'Europa i sjeverna Azija', '308', '132', 

'/media/CRVENA_VJEVERICA.jpg');

INSERT INTO `species` (`species_id`, `name`, `family_id`, `size`, `nutrition`, `predators`, `lifetime`, `habitat`, 

`lifestyle`, `reproduction`, `distribution`, `location_x`, `location_y`, `photo_path`) VALUES ('10', 'CRNI URLIKAVAC 

(Alouatta caraya)', '9', 'Veličina tijela: mužjaci do 60 cm, a ženke do 48 cm, rep je slične dužine kao i tijelo
Težina tijela: 4 do 10 kg', 'U prirodi: lišće, plodovi i cvijeće
U zoo vrtu: biljna hrana', 'Ptice grabljivice, ljudi', 'U prirodi: 20 godina
U zoo vrtu: 20.3 godina', 'Tropske kišne šume', 'Većinom žive u većim društvenim skupinama sačinjenim od nekoliko 

obitelji. Ženke u skupinama često se brinu i za tuđe mlade, a to je primijećeno i kod starijih mužjaka. Mladi mužjaci 

su grubi i često znaju ubiti mladunčad, stoga im skupina ne dozvoljava da brinu za mlade. Urlikavci su teritorijalni, 

ali brane samo područje na kojem se trenutno nalaze. Teritoriji skupina se često isprepliću. Rano ujutro cijela 

skupina se glasa kako bi obilježila svoji teritorij. ', 'Period gestacije ovisi o starosti ženke, kraći je kod 

starijih ženki, a može trajati od 7 do 12 mjeseci. Mladunče ima žuto krzno. Majka brine za mlado oko godinu dana. 

Mlade ženke ostaju u skupini, a mladi mužjaci je moraju napustiti. ', 'Južna Amerika', '385', '195', 

'/media/CRNI_URLIKAVAC.jpg');


INSERT INTO `species` (`species_id`, `name`, `family_id`, `size`, `nutrition`, `predators`, `lifetime`, `habitat`, 

`lifestyle`, `reproduction`, `distribution`, `location_x`, `location_y`, `photo_path`) VALUES ('11', 'LJUBIČASTOPRSA 

AMAZONA (Amazona vinacea)', '10', 'Veličina tijela: 30 cm
Težina tijela: 370 g', 'U prirodi: razne sjemenke, cvijeće, voće
U zoo vrtu: sjemenke, voće', 'Nema dostupnih podataka', 'Nema dostupnih podataka', 'Šume i rubovi šuma', 'Izvan sezone 

parenja vrlo su društvene ptice, a Jato je uvijek na okupu. Pri glasanju i sporazumijevanju proizvode različite 

zvukove. ', 'Sezona razmnožavanja je od kolovoza do prosinca, a parovi se pare u šupljinama stabala. ', 'Jugoistok 

Južne Amerike', '147', '232', '/media/LJUBIČASTOPRSA_AMAZONA.jpg');


INSERT INTO `species` (`species_id`, `name`, `family_id`, `size`, `nutrition`, `predators`, `lifetime`, `habitat`, 

`lifestyle`, `reproduction`, `distribution`, `location_x`, `location_y`, `photo_path`) VALUES ('12', 'BARBET 

(Trachyphonus erythrocephalus)', '11', 'Veličina tijela: 20 do 23 cm
Težina tijela: 40 do 75 g', 'U prirodi: voće, bobice, kukci, manje ptice
U zoo vrtu: ', 'Nema dostupnih podataka', 'Nema dostupnih podataka', 'Polupustinje i stepe', 'Žive u skupini koju čine 

članovi obitelji. Skupina ne migrira, osim u potrazi za hranom. Vrlo su teritorijalni. ', 'Nakon kišnih sezona slijedi 

parenje, a tijekom gniježđenja sve jedinke u skupini kopaju tunele. Ženka liježe 4 do 5 jaja. ', 'Istok Afrike ', 

'147', '232', '/media/BARBET.jpg');


INSERT INTO `species` (`species_id`, `name`, `family_id`, `size`, `nutrition`, `predators`, `lifetime`, `habitat`, 

`lifestyle`, `reproduction`, `distribution`, `location_x`, `location_y`, `photo_path`) VALUES ('13', 'BATOKLJUN 

(Coccothraustes choccothraustes)', '12', 'Veličina tijela: 16 do 18 cm
Težina tijela: 48 do 62 g', 'U prirodi: Sjemenke i kukci
U zoo vrtu: Sjemenke i kukci', 'Nema dostunih podataka', 'Nema dostunih podataka', 'Šume, područja uz rijeke, 

parkovi', 'Povučena ptica teško primjetna ljudima pa tako i grabežljivcima. Obitava u višim slojevima krošnje ili 

ljeti pri tlu kada hvata kukce za mlade. ', 'Sezona razmnožavanja počinje krajem travnja. Europske kolonije su 

stanarice, a azijske selice. Gnijezde se u skupinama do šest parova. Ženke liježu 2 do 9 jaja koja inkubiraju do 14 

dana. Mogu imati do dva legla godišnje. ', 'Europa i Azija', '174', '232', '/media/BATOKLJUN.jpg');


INSERT INTO `species` (`species_id`, `name`, `family_id`, `size`, `nutrition`, `predators`, `lifetime`, `habitat`, 

`lifestyle`, `reproduction`, `distribution`, `location_x`, `location_y`, `photo_path`) VALUES ('14', 'TREPAVIČASTA 

JAMIČARKA (Bothriechis schlegelii)', '13', 'Veličina tijela: od 35 do 82 cm', 'U prirodi: mali sisavci, ptice, žabe, 

šišmiši
U zoo vrtu: miševi i štakori', 'Ljudi, mačke, ježevi, jazavci, lisice', 'U prirodi: 6 do 10 godina
U zoo vrtu: 16 do 20 godina', 'Tropske šume, razna staništa u blizini vode', 'Većinom su noćne i samotnjačke zmije. 

Tijekom lova se oslanjaju na zasjedu, a mirovanje i zadržavanje na istom mjestu i same ih čini podložnima predaciji. 

Međutim, zbog boja i mirovanja su većini životinja neprimjetne, barem do neposredne blizine. Većinu vremena provode u 

krošnjama, čekajući plijen.', 'Potencijalne partnere pronalaze preciznim njuhom. Prije parenja mužjaci se udvaraju 

ženki te se međusobno sukobljuju. Dva mužjaka zauzimaju stav sličan kobrinom te se zastrašuju. Sukob nije agresivan, 

često traje satima, a mužjak gubitnik često padne s grane. Mogu se pariti čitave godine, a samo parenje odvija se 

noću. Ženke u sebi nose jaja oko 6 mjeseci, nakon čega iz njih izlazi 2 do 20 živih mladih. ', 'Središnja Amerika, od 

Meksika do Venezuele ', '110', '283', '/media/TREPAVIČASTA_JAMIČARKA.jpg');

INSERT INTO `species` (`species_id`, `name`, `family_id`, `size`, `nutrition`, `predators`, `lifetime`, `habitat`, 

`lifestyle`, `reproduction`, `distribution`, `location_x`, `location_y`, `photo_path`) VALUES ('15', 'RIĐOVKA (Vipera 

berus)', '13', 'Veličina tijela: do 80 cm
Težina tijela: 50 do 100 g', 'U prirodi: manji sisavci, gušteri ptice i žabe
U zoo vrtu: miševi i štakori', 'Lisice, svisci, dnevne ptice grabljivice i sove', 'U prirodi: 10 do 25 godina
U zoo vrtu: 10 do 15 godina', 'Razna staništa od šuma do livada.', 'Samotnjačke su životinje, a okupljaju se samo za 

sezone parenja ili hibernacije. Većinu dana miruju i prikupljaju energiju sunčajući se, a najaktivniji su prije 

zalaska Sunca, kada i love. Tijekom rujna ili listopada do 100 jedinki se okuplja u napuštenim brlozima ili jazbinama 

te započinje hibernaciju. Pošto je riđovka široko rasprostranjena hibernacija se javlja samo kod onih na hladnijim 

područjima, dok one u umjerenim i toplim mogu biti aktivne cijelu godinu. ', 'Sezona parenja nastupa u proljeće, nakon 

zimske hibernacije odnosno zimskog sna. Mužjaci se bude prvi i miruju dok se ne pojave ženke. Tada velik broj okružuje 

ženku te se mogu i boriti, a ona bira s kime će se pariti. Nakon parenja mužjak neko vrijeme čuva ženku kako se ne bi 

ponovo parila. Do 12 jaja se 3 do 4 mjeseca razvija unutar ženke te u jesen izlaze živi mladi, najčešće za vrijeme 

hibernacije.', 'Od Velike Britanije do pacifičke obale Azije', '110', '283', '/media/RIĐOVKA.jpg');


INSERT INTO `species` (`species_id`, `name`, `family_id`, `size`, `nutrition`, `predators`, `lifetime`, `habitat`, 

`lifestyle`, `reproduction`, `distribution`, `location_x`, `location_y`, `photo_path`) VALUES ('16', 'OBIČNA ČANČARA 

(Testudo hermanni)', '14', 'Veličina tijela: od 12 do 23 cm
Težina tijela: od 2 do 2,5 kg', 'U prirodi: trava, lišće, cvijeće, a rjeđe kukci, puževi i gujavice', 'Mlade često 

love ptice grabljivice, štakori, zmije, veprovi, lisice, ježevi i jazavci', 'U prirodi: nema dostupnih podataka
U zoo vrtu: preko 100 godina', 'Šume i obalna šumska područja', 'Aktivne su danju te većinu vremena provode hraneći se 

ili mirujući na suncu ili u hladu. Tijekom zime hiberniraju, odnosno spavaju zimski san. Odrasli se zbog čvrstog 

oklopa vrlo rijetko nađu na jelovniku, stoga nemaju mnogo prirodnih neprijatelja. Ukoliko je sušna sezona ili pojedu 

svu biljnu hranu na nekom području, počet će se hraniti malim beskralježnjacima. ', 'Razmnožavaju se sezonski, u 

veljači, nakon zimske hibernacije. Ženke u ranijoj dobi dostižu spolnu zrelost. Ženke biraju mužjake na temelju 

izgleda, glasanja i mirisa. Prije parenja mužjaci ženke ugrizu za nogu, ali mnogo nježnije nego kod drugih vrsta 

kornjača. I mužjaci i ženke imaju više partnera tokom sezone parenja. Ženka iskopa jednu ili nekoliko rupa u koje 

poliježe jaja, a nakon 90 dana inkubacije izlaze mladi. ', 'Sjeverna obala Mediterana', '110', '283', 

'/media/OBIČNA_ČANČARA.jpg');



INSERT INTO `species` (`species_id`, `name`, `family_id`, `size`, `nutrition`, `predators`, `lifetime`, `habitat`, 

`lifestyle`, `reproduction`, `distribution`, `location_x`, `location_y`, `photo_path`) VALUES ('17', 'ZLATNA OTROVNA 

ŽABA (Phyllobates terribilis)', '15', 'Veličina tijela: 4,7 do 5,5 cm', 'U prirodi: mravi, termiti, kornjaši
U zoo vrtu: juvenilni kukci', 'Zbog boje i otrovnosti jedini poznati predator je zmija Liophis epinephelus koja se 

hrani mladim jedinkama', 'U prirodi: do 5 godina
U zoo vrtu: do 5 godina', 'Tropska kišna šuma', 'Strogo su kopnene i dnevne životinje. Zbog boje i otrovnosti se ne 

boje predacije te stoga i ne bježe od predatora, ali ukoliko se nađu u drugoj opasnosti brzo će se sakriti. Za razliku 

od mnogih drugih žaba, bez kompeticije i sukoba mogu živjeti u većim skupinama u zatočeništvu', 'Mužjaci i ženke imaju 

mnogo partnera, a razmnožavanje je pobliže istraženo samo u zatočeništvu. U parenju sudjeluje jedna ženka i nekoliko 

mužjaka. Mužjaci privlače ženke proizvodeći nekoliko visokih tonova. Tijekom parenja svi sudionici skaču te ispuštaju 

jajašca ili spermije. Oplođena jaja nisu pronađena u prirodi, ali su se u zatočeništvu izlegla nakon 11 do 12 dana. ', 

'Mali dio pacifičke obale Kolumbije', '110', '283', '/media/ZLATNA_OTROVNA_ŽABA.jpg');


INSERT INTO `species` (`species_id`, `name`, `family_id`, `size`, `nutrition`, `predators`, `lifetime`, `habitat`, 

`lifestyle`, `reproduction`, `distribution`, `location_x`, `location_y`, `photo_path`) VALUES ('18', 'ŠARENI 

DAŽDEVNJAK (Salamandra salamandra)', '16', 'Veličina tijela: 15 do 30 cm
Težina tijela: 19,1 g', 'U prirodi: gujavice, puževi, kukci
U zoo vrtu: ', 'Nema podataka, ali zbog obojenja i otrovnosti su odbojni grabežljivcima', 'U prirodi: do 24 godina
U zoo vrtu: do 24 godina', 'Vlažne šume s puno hlada, potoka i jezerca', 'Sramežljiva su i samotnjačka vrsta i većinu 

vremena provode mirujući pod hladom, u vlažnijim skrivenim mjestima. Najaktivniji su sredinom noći. Većinom se 

zadržavaju u blizini skrovišta.', 'Sezona parenja je u ljeto, kada mužjaci u ženku izlučuju spermatofor, vrećicu sa 

spermom. Ženke u umjerenim područjima čuvaju spermatofor pa se tako mladi izliježu tek u proljeće, nakon zimske 

hibernacije. U toplijim krajevima mladi se izliježu nakon listopada pa sve do siječnja. Mladi se razvijaju unutar 

ženke te izlaze razvijeni i spremni. Parenje se odvija na kopnu, a mlade ženka ispušta u vodu.  ', 'Središnja i južna 

Europa, sjever Afrike i Bliski istok ', '110', '283', '/media/ŠARENI_DAŽDEVNJAK.jpg');

INSERT INTO `species` (`species_id`, `name`, `family_id`, `size`, `nutrition`, `predators`, `lifetime`, `habitat`, 

`lifestyle`, `reproduction`, `distribution`, `location_x`, `location_y`, `photo_path`) VALUES ('19', 'OKLOPNIČAR 

(Hypostomus sp.)', '17', 'Duljina tijela: 28 cm', 'U prirodi: alge, biljke, ličinke', 'nema dostupnih podataka', 'U 

prirodi: nema dostupnih podataka
U zoo vrtu: nema dostupnih podataka', 'Šljunčano, slatkovodno dno ', 'Pridnene vrste; loši su plivači', 'Kopaju tunele 

u obali u koje stavljaju jajašca. Mužjaci čuvaju oplođena jajašca i ličinke.', 'Šljunčano, slatkovodno dno', '110', 

'283', '/media/OKLOPNIČAR.jpg');

INSERT INTO `species` (`species_id`, `name`, `family_id`, `size`, `nutrition`, `predators`, `lifetime`, `habitat`, 

`lifestyle`, `reproduction`, `distribution`, `location_x`, `location_y`, `photo_path`) VALUES ('20', 'AFRIČKI SOM 

(Synodontis sp.)', '18', 'Duljina tijela: do 26 cm', 'U prirodi: biljna prehrana, vodeni beskralješnjaci, ličinke 

kukaca
U zoo vrtu: dehidrirana hrana na biljnoj bazi, dehidrirana hrana na bazi račića', 'Nema dostupnih podataka', 'U 

prirodi: nema dostupnih podataka
U zoo vrtu: nema dostupnih podataka', 'Slatka voda', 'Omnivori su, hrane se i detritusom, ali i filtriranjem. To im 

pomaže da se lakše prilagode sezonskim promjenama staništa. Primječeno je da se razmnožavaju za vrijeme poplava u 

razdoblju kišne sezone.', 'Ženka polaže oplođena jajašca na vodeno bilje. Nakon nekog vremena se razviju ličinke o 

kojima ženka ne brine.', 'Afrika', '110', '283', '/media/AFRIČKI_SOM.jpg');





INSERT INTO `mammal_animals` (`animal_id`, `species_id`, `name`, `sex`, `birth_location`, `arrival_date`, 

`photo_path`, `interesting_facts`) VALUES ('1', '8', 'Karlo', 'M', 'Kina', '2016-12-01', 

'/media/PATULJASTA_KOZA_Karlo_photo1.jpg', 'Zbog duge povijesti domestifikacije postoje različite veličine i boje 

domaće koze. Mužjaci su obično veći od ženki. Boja krzna može biti crna, bijela, smeđa i crvena, a uzorci boja 

različiti. Rep je kratak i zavinut prema gore. ');

INSERT INTO `mammal_animals` (`animal_id`, `species_id`, `name`, `sex`, `birth_location`, `arrival_date`, 

`photo_path`, `interesting_facts`) VALUES ('2', '8', 'Luka', 'M', 'Kutina', '2016-12-01', 

'/media/PATULJASTA_KOZA_Luka_photo1.jpg', 'Zbog duge povijesti domestifikacije postoje različite veličine i boje 

domaće koze. Mužjaci su obično veći od ženki. Boja krzna može biti crna, bijela, smeđa i crvena, a uzorci boja 

različiti. Rep je kratak i zavinut prema gore. ');

INSERT INTO `mammal_animals` (`animal_id`, `species_id`, `name`, `sex`, `birth_location`, `arrival_date`, 

`photo_path`, `interesting_facts`) VALUES ('3', '8', 'Kata', 'Ž', 'Rakov Potok', '2016-12-01', 

'/media/PATULJASTA_KOZA_Kata_photo1.jpg', 'Zbog duge povijesti domestifikacije postoje različite veličine i boje 

domaće koze. Mužjaci su obično veći od ženki. Boja krzna može biti crna, bijela, smeđa i crvena, a uzorci boja 

različiti. Rep je kratak i zavinut prema gore. ');

INSERT INTO `mammal_animals` (`animal_id`, `species_id`, `name`, `age`, `sex`, `birth_location`, `arrival_date`, 

`photo_path`, `interesting_facts`) VALUES ('4', '3', 'Marko', '', 'M', 'Zoo Zagreb', '2016-12-01', 

'/media/PLANINSKI_PEĆINAR_Marko_photo1.jpg', 'Oči planinskih pećinara imaju dodatni zaštitni sloj, umbraculum, koji ih 

štiti od sunčevih zraka.
Gestacija traje 6 do 8 mjeseci što je neobično dugo za sisavca ove veličine. ');

INSERT INTO `mammal_animals` (`animal_id`, `species_id`, `name`, `sex`, `birth_location`, `arrival_date`, 

`photo_path`, `interesting_facts`) VALUES ('5', '3', 'Pero', 'M', 'Zoo Zagreb', '2016-12-01', 

'/media/PLANINSKI_PEĆINAR_Pero_photo1.jpg', 'Oči planinskih pećinara imaju dodatni zaštitni sloj, umbraculum, koji ih 

štiti od sunčevih zraka.
Gestacija traje 6 do 8 mjeseci što je neobično dugo za sisavca ove veličine. ');

INSERT INTO `mammal_animals` (`animal_id`, `species_id`, `name`, `sex`, `birth_location`, `arrival_date`, 

`photo_path`, `interesting_facts`) VALUES ('6', '3', 'Đurđa', 'Ž', 'Zoo Zagreb', '2016-12-01', 

'/media/PLANINSKI_PEĆINAR_Đurđa_photo1.jpeg', 'Oči planinskih pećinara imaju dodatni zaštitni sloj, umbraculum, koji 

ih štiti od sunčevih zraka.
Gestacija traje 6 do 8 mjeseci što je neobično dugo za sisavca ove veličine. ');


INSERT INTO `mammal_animals` (`animal_id`, `species_id`, `name`, `sex`, `birth_location`, `arrival_date`, 

`photo_path`, `interesting_facts`) VALUES ('7', '10', 'Tobi', 'M', 'Brasília', '2016-12-01', 

'/media/CRNI_URLIKAVAC_Tobi_photo1.jpg', 'Pošto više skupina obitavaju na istom teritoriju, urlikavci se glasaju svako 

jutro kako bi drugim skupinama dali do znanja gdje se nalaze. Isto tako, teritorij obilježavaju i trljanjem o grane 

ili ostavljanjem većih hrpa izmeta.');

INSERT INTO `mammal_animals` (`animal_id`, `species_id`, `name`, `sex`, `birth_location`, `arrival_date`, 

`photo_path`, `interesting_facts`) VALUES ('8', '10', 'Dario', 'M', 'Brasília', '2016-12-01', 

'/media/CRNI_URLIKAVAC_Dario_photo1.jpg', 'Pošto više skupina obitavaju na istom teritoriju, urlikavci se glasaju 

svako jutro kako bi drugim skupinama dali do znanja gdje se nalaze. Isto tako, teritorij obilježavaju i trljanjem o 

grane ili ostavljanjem većih hrpa izmeta.');

INSERT INTO `mammal_animals` (`animal_id`, `species_id`, `name`, `sex`, `birth_location`, `arrival_date`, 

`photo_path`, `interesting_facts`) VALUES ('9', '10', 'Diego', 'M', 'Brasília', '2016-12-01', 

'/media/CRNI_URLIKAVAC_Diego_photo1.jpg', 'Pošto više skupina obitavaju na istom teritoriju, urlikavci se glasaju 

svako jutro kako bi drugim skupinama dali do znanja gdje se nalaze. Isto tako, teritorij obilježavaju i trljanjem o 

grane ili ostavljanjem većih hrpa izmeta.');

INSERT INTO `mammal_animals` (`animal_id`, `species_id`, `name`, `sex`, `birth_location`, `arrival_date`, 

`photo_path`, `interesting_facts`) VALUES ('10', '10', 'Robi', 'M', 'Brasília', '2016-12-01', 

'/media/CRNI_URLIKAVAC_Robi_photo1.jpg', 'Pošto više skupina obitavaju na istom teritoriju, urlikavci se glasaju svako 

jutro kako bi drugim skupinama dali do znanja gdje se nalaze. Isto tako, teritorij obilježavaju i trljanjem o grane 

ili ostavljanjem većih hrpa izmeta.');

INSERT INTO `mammal_animals` (`animal_id`, `species_id`, `name`, `sex`, `birth_location`, `arrival_date`, 

`photo_path`, `interesting_facts`) VALUES ('11', '10', 'Kiki', 'M', 'Brasília', '2016-12-01', 

'/media/CRNI_URLIKAVAC_Kiki_photo1.jpg', 'Pošto više skupina obitavaju na istom teritoriju, urlikavci se glasaju svako 

jutro kako bi drugim skupinama dali do znanja gdje se nalaze. Isto tako, teritorij obilježavaju i trljanjem o grane 

ili ostavljanjem većih hrpa izmeta.');

INSERT INTO `mammal_animals` (`animal_id`, `species_id`, `name`, `sex`, `birth_location`, `arrival_date`, 

`photo_path`, `interesting_facts`) VALUES ('12', '10', 'Suza', 'Ž', 'Brasília', '2016-12-01', 

'/media/CRNI_URLIKAVAC_Suza_photo1.jpg', 'Pošto više skupina obitavaju na istom teritoriju, urlikavci se glasaju svako 

jutro kako bi drugim skupinama dali do znanja gdje se nalaze. Isto tako, teritorij obilježavaju i trljanjem o grane 

ili ostavljanjem većih hrpa izmeta.');
